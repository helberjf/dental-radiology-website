import { ChevronDown } from "lucide-react";
import { useState } from "react";
import { Service } from "@/data/services";
import { whatsappLink } from "@/data/company";
import { toast } from "sonner";

interface ServiceCardProps {
  service: Service;
  reviewCount?: number;
  averageRating?: number;
}

export function ServiceCard({
  service,
}: ServiceCardProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleWhatsApp = () => {
    const message = `Olá, vim do site e gostaria de fazer um orçamento de ${service.name}`;
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/5532991392808?text=${encodedMessage}`;
    console.log('WhatsApp URL:', whatsappUrl);
    window.open(whatsappUrl, "_blank");
  };

  const handleAddToCart = () => {
    const event = new CustomEvent('addToCart', { 
      detail: { 
        serviceId: service.id, 
        serviceName: service.name, 
        price: service.price 
      } 
    });
    window.dispatchEvent(event);
    // Toast será disparado pelo Cart.tsx
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="text-5xl mb-4">{service.icon}</div>
        <h3 className="text-2xl font-bold text-black mb-2 font-serif">
          {service.name}
        </h3>
        <p className="text-gray-600 text-sm">{service.description}</p>
      </div>

      {/* Price */}
      <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
        <p className="text-gray-600 text-sm mb-1">Preço do Serviço</p>
        <p className="text-3xl font-bold text-green-600">
          R$ {service.price.toFixed(2)}
        </p>
      </div>

      {/* Buttons */}
      <div className="p-6 space-y-3">
        <button
          onClick={handleWhatsApp}
          className="w-full bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
        >
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.946 1.347l-.355.187-.368-.06c-1.286-.264-2.514-.666-3.554-1.223l-.636-.341.12.754c.596 3.787 3.707 6.778 7.532 7.316l.529.034-.079.468c-.165.983.057 1.97.537 2.807.211.383.432.757.659 1.117l.235.355-.355.236a9.964 9.964 0 01-5.076 1.522c-.821 0-1.629-.089-2.414-.267l-.652-.134-1.029.655c-.507.323-.993.656-1.451 1.005l-.228.164.164-.228c.349-.458.682-.944 1.005-1.451l.655-1.029-.134-.652a9.87 9.87 0 01-.267-2.414c0-5.471 4.409-9.922 9.868-9.922 2.646 0 5.147.997 7.078 2.837l.405.376.376-.405a9.865 9.865 0 002.837-7.078c0-5.471-4.409-9.922-9.868-9.922"/>
          </svg>
          Solicitar Serviço
        </button>

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full bg-gray-200 hover:bg-gray-300 text-black font-semibold py-2 px-4 rounded-lg transition-colors flex items-center justify-between"
        >
          Ver Detalhes
          <ChevronDown
            size={20}
            className={`transition-transform ${isOpen ? "rotate-180" : ""}`}
          />
        </button>

        <button
          onClick={() => {
            handleAddToCart();
          }}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
        >
          🛒 Adicionar ao Carrinho
        </button>
      </div>

      {/* Toggle Description */}
      {isOpen && (
        <div className="px-6 pb-6 border-t border-gray-200 bg-gray-50">
          <p className="text-gray-700 text-sm leading-relaxed">
            {service.fullDescription}
          </p>
        </div>
      )}

      {/* Review Section */}
      <div className="px-6 py-4 border-t border-gray-200 bg-white">
        <p className="text-sm text-gray-600 mb-3">Avalie este serviço:</p>
        <div className="flex gap-2">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              className="text-2xl hover:scale-110 transition-transform"
              title={`${star} estrela${star > 1 ? "s" : ""}`}
            >
              ⭐
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
