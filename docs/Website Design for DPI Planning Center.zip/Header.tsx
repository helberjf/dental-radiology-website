import { Menu, ShoppingCart, X } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { company } from "@/data/company";
import { Button } from "@/components/ui/button";

export function Header() {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { label: "Home", href: "/" },
    { label: "Serviços", href: "/servicos" },
    { label: "Contato", href: "/contato" },
  ];

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
      <div className="container py-4 flex items-center justify-between">
        <Link href="/">
          <a className="flex items-center gap-2">
            <img
              src={company.logo}
              alt={company.name}
              className="h-14 w-auto hover:opacity-80 transition-opacity"
            />
          </a>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <a className="text-gray-700 hover:text-gray-900 transition-colors font-semibold text-sm">
                {item.label}
              </a>
            </Link>
          ))}
        </nav>

        {/* Desktop CTA */}
        <div className="hidden md:flex items-center gap-4">
          <Button
            variant="default"
            className="bg-green-500 hover:bg-green-600 text-white font-semibold"
          >
            Fazer Orçamento
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden p-2 hover:bg-gray-100 rounded"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden border-t border-gray-200 bg-gray-50">
          <nav className="container py-4 flex flex-col gap-4">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a
                  className="text-gray-700 hover:text-gray-900 transition-colors font-semibold"
                  onClick={() => setIsOpen(false)}
                >
                  {item.label}
                </a>
              </Link>
            ))}
            <Button
              variant="default"
              className="bg-green-500 hover:bg-green-600 text-white w-full font-semibold"
            >
              Fazer Orçamento
            </Button>
          </nav>
        </div>
      )}
    </header>
  );
}
