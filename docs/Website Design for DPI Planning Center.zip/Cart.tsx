import { ShoppingCart, X, Trash2, CheckCircle, ArrowLeft } from "lucide-react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { whatsappLink } from "@/data/company";
import { toast } from "sonner";

export interface CartItem {
  serviceId: string;
  serviceName: string;
  price: number;
  quantity: number;
}

export function Cart() {
  const [isOpen, setIsOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [showConfirmation, setShowConfirmation] = useState(false);

  // Carregar carrinho do localStorage ao montar
  useEffect(() => {
    const savedCart = localStorage.getItem('dpi-cart');
    if (savedCart) {
      try {
        setCartItems(JSON.parse(savedCart));
      } catch (error) {
        console.error('Erro ao carregar carrinho:', error);
      }
    }
  }, []);

  // Salvar carrinho no localStorage sempre que mudar
  useEffect(() => {
    localStorage.setItem('dpi-cart', JSON.stringify(cartItems));
  }, [cartItems]);

  // Listener para adicionar ao carrinho
  useEffect(() => {
      const handleAddToCart = (event: Event) => {
        const customEvent = event as CustomEvent;
        const { serviceId, serviceName, price } = customEvent.detail;
        
        setCartItems((prevItems) => {
          const existing = prevItems.find((item) => item.serviceId === serviceId);
          let newItems;
          if (existing) {
            newItems = prevItems.map((item) =>
              item.serviceId === serviceId
                ? { ...item, quantity: item.quantity + 1 }
                : item
            );
          } else {
            newItems = [...prevItems, { serviceId, serviceName, price, quantity: 1 }];
          }
          
          // Toast de sucesso
          toast.success(`${serviceName} adicionado ao carrinho!`, {
            description: `Preço: R$ ${price.toFixed(2)}`,
            duration: 3000,
          });
          
          return newItems;
        });
      };

    window.addEventListener('addToCart', handleAddToCart);
    return () => window.removeEventListener('addToCart', handleAddToCart);
  }, []);

  const total = cartItems.reduce((sum, item) => {
    return sum + item.price * item.quantity;
  }, 0);

  const removeFromCart = (serviceId: string) => {
    setCartItems(cartItems.filter((item) => item.serviceId !== serviceId));
  };

  const updateQuantity = (serviceId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(serviceId);
    } else {
      setCartItems(
        cartItems.map((item) =>
          item.serviceId === serviceId ? { ...item, quantity } : item
        )
      );
    }
  };

  const handleCheckout = () => {
    const itemsList = cartItems
      .map((item) => {
        const subtotal = (item.price * item.quantity).toFixed(2);
        return `📌 ${item.serviceName}\n   Quantidade: ${item.quantity}x\n   Preço unitário: R$ ${item.price.toFixed(2)}\n   Subtotal: R$ ${subtotal}`;
      })
      .join("\n\n");

    const message = `🦷 *SOLICITAÇÃO DE ORÇAMENTO - DPI PLANNING CENTER*\n\n👋 Olá! Vim do site e gostaria de fazer um orçamento dos seguintes serviços:\n\n${itemsList}\n\n${'─'.repeat(40)}\n\n💰 *RESUMO DO PEDIDO*\n📊 Quantidade de itens: ${cartItems.length}\n📈 Total de serviços: ${cartItems.reduce((sum, item) => sum + item.quantity, 0)}\n💵 *Valor Total: R$ ${total.toFixed(2)}*\n\n${'─'.repeat(40)}\n\n⏰ Aguardo retorno com a confirmação de disponibilidade e próximos passos.\n\nObrigado!`;
    const encodedMessage = encodeURIComponent(message);
    window.open(`${whatsappLink}&text=${encodedMessage}`, "_blank");
    
    // Toast de sucesso
    toast.success('Pedido enviado com sucesso!', {
      description: 'Você será redirecionado para o WhatsApp',
      duration: 3000,
    });
    
    // Limpar carrinho após enviar
    setTimeout(() => {
      setCartItems([]);
      localStorage.removeItem('dpi-cart');
    }, 1000);
    
    setShowConfirmation(false);
    setIsOpen(false);
  };

  return (
    <>
      {/* Cart Button - Floating */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 right-6 z-40 bg-gray-800 hover:bg-gray-700 text-white rounded-full p-4 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-110 animate-fade-in"
        aria-label="Abrir carrinho"
      >
        <div className="relative">
          <ShoppingCart size={28} />
          {cartItems.length > 0 && (
            <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center animate-pulse">
              {cartItems.length}
            </span>
          )}
        </div>
      </button>

      {/* Cart Fullscreen Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 bg-white flex flex-col overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-gray-900 to-gray-800 text-white p-6 flex items-center justify-between shadow-lg">
            <div className="flex items-center gap-3">
              <ShoppingCart size={32} />
              <h1 className="text-2xl md:text-3xl font-bold">Meu Carrinho</h1>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 md:p-2 hover:bg-gray-700 rounded-lg transition-colors"
              aria-label="Fechar carrinho"
            >
              <X size={24} className="md:w-8 md:h-8" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {cartItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <ShoppingCart size={80} className="text-gray-300 mb-6" />
                <p className="text-gray-500 text-2xl font-semibold mb-4">
                  Seu carrinho está vazio
                </p>
                <p className="text-gray-400 text-lg">
                  Adicione serviços para começar
                </p>
              </div>
            ) : (
              <div className="space-y-4 max-w-4xl mx-auto">
                {cartItems.map((item) => (
                  <div
                    key={item.serviceId}
                    className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 rounded-lg border border-gray-200 hover:border-gray-300 transition-all animate-fade-in-up"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <p className="font-bold text-black text-xl">
                          {item.serviceName}
                        </p>
                        <p className="text-green-600 font-bold text-2xl mt-2">
                          R$ {item.price.toFixed(2)}
                        </p>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.serviceId)}
                        className="p-3 hover:bg-red-100 rounded-lg text-red-600 transition-colors"
                        title="Remover do carrinho"
                      >
                        <Trash2 size={24} />
                      </button>
                    </div>
                    <div className="flex items-center gap-3 bg-white rounded-lg p-3 w-fit">
                      <button
                        onClick={() =>
                          updateQuantity(item.serviceId, item.quantity - 1)
                        }
                        className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded font-bold text-gray-700 transition-colors"
                      >
                        −
                      </button>
                      <span className="px-6 py-2 font-bold text-black text-lg">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() =>
                          updateQuantity(item.serviceId, item.quantity + 1)
                        }
                        className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded font-bold text-gray-700 transition-colors"
                      >
                        +
                      </button>
                    </div>
                    <div className="mt-4 text-right">
                      <p className="text-gray-600 text-lg">
                        Subtotal: <span className="font-bold text-black">R$ {(item.price * item.quantity).toFixed(2)}</span>
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer - Summary */}
          {cartItems.length > 0 && (
            <div className="bg-gray-50 border-t border-gray-200 p-4 md:p-6 space-y-3 md:space-y-4">
              <div className="max-w-4xl mx-auto">
                {/* Summary Box */}
                <div className="bg-white rounded-lg p-4 md:p-6 border border-gray-200 space-y-2 md:space-y-3 mb-4 md:mb-6">
                  <div className="flex justify-between text-sm md:text-lg">
                    <span className="text-gray-600">Quantidade de itens:</span>
                    <span className="font-bold text-black">{cartItems.length}</span>
                  </div>
                  <div className="flex justify-between text-sm md:text-lg">
                    <span className="text-gray-600">Total de serviços:</span>
                    <span className="font-bold text-black">
                      {cartItems.reduce((sum, item) => sum + item.quantity, 0)}
                    </span>
                  </div>
                  <div className="border-t border-gray-200 pt-2 md:pt-3 flex justify-between items-center">
                    <span className="text-gray-600 font-bold text-sm md:text-lg">Total:</span>
                    <span className="text-2xl md:text-4xl font-bold text-green-600">
                      R$ {total.toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-4">
                  <Button
                    onClick={() => setIsOpen(false)}
                    className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 md:py-4 text-xs md:text-lg font-semibold flex items-center justify-center gap-1 md:gap-2 transition-colors whitespace-nowrap"
                  >
                    <ArrowLeft size={16} className="md:w-5 md:h-5" />
                    <span className="hidden md:inline">Continuar Comprando</span>
                    <span className="md:hidden">Voltar</span>
                  </Button>
                  <Button
                    onClick={() => setShowConfirmation(true)}
                    className="flex-1 bg-green-500 hover:bg-green-600 text-white py-2 md:py-4 text-xs md:text-lg font-semibold flex items-center justify-center gap-1 md:gap-2 transition-colors whitespace-nowrap"
                  >
                    <svg className="w-3 h-3 md:w-5 md:h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.946 1.347l-.355.187-.368-.06c-1.286-.264-2.514-.666-3.554-1.223l-.636-.341.12.754c.596 3.787 3.707 6.778 7.532 7.316l.529.034-.079.468c-.165.983.057 1.97.537 2.807.211.383.432.757.659 1.117l.235.355-.355.236a9.964 9.964 0 01-5.076 1.522c-.821 0-1.629-.089-2.414-.267l-.652-.134-1.029.655c-.507.323-.993.656-1.451 1.005l-.228.164.164-.228c.349-.458.682-.944 1.005-1.451l.655-1.029-.134-.652a9.87 9.87 0 01-.267-2.414c0-5.471 4.409-9.922 9.868-9.922 2.646 0 5.147.997 7.078 2.837l.405.376.376-.405a9.865 9.865 0 002.837-7.078c0-5.471-4.409-9.922-9.868-9.922"/>
                    </svg>
                    <span className="hidden md:inline">Finalizar Pedido</span>
                    <span className="md:hidden">Finalizar</span>
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Confirmation Modal */}
      {showConfirmation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
          <div className="bg-white rounded-lg shadow-2xl max-w-md w-full p-8 animate-fade-in-up">
            {/* Header */}
            <div className="text-center mb-6">
              <CheckCircle size={48} className="mx-auto text-green-500 mb-4" />
              <h2 className="text-2xl font-bold text-black mb-2">
                Confirmar Pedido
              </h2>
              <p className="text-gray-600 text-sm">
                Revise seu pedido antes de enviar para WhatsApp
              </p>
            </div>

            {/* Order Summary */}
            <div className="bg-gray-50 rounded-lg p-6 mb-6 space-y-3 max-h-64 overflow-y-auto">
              {cartItems.map((item) => (
                <div key={item.serviceId} className="flex justify-between items-center pb-3 border-b border-gray-200 last:border-b-0">
                  <div>
                    <p className="font-semibold text-black text-sm">
                      {item.serviceName}
                    </p>
                    <p className="text-gray-600 text-xs">
                      Quantidade: {item.quantity}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-600">
                      R$ {(item.price * item.quantity).toFixed(2)}
                    </p>
                    <p className="text-gray-600 text-xs">
                      R$ {item.price.toFixed(2)} cada
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Total */}
            <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-4 mb-6 border border-green-200">
              <div className="flex justify-between items-center">
                <span className="text-gray-700 font-semibold">Valor Total:</span>
                <span className="text-4xl font-bold text-green-600">
                  R$ {total.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button
                onClick={handleCheckout}
                className="w-full bg-green-500 hover:bg-green-600 text-white py-3 font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.946 1.347l-.355.187-.368-.06c-1.286-.264-2.514-.666-3.554-1.223l-.636-.341.12.754c.596 3.787 3.707 6.778 7.532 7.316l.529.034-.079.468c-.165.983.057 1.97.537 2.807.211.383.432.757.659 1.117l.235.355-.355.236a9.964 9.964 0 01-5.076 1.522c-.821 0-1.629-.089-2.414-.267l-.652-.134-1.029.655c-.507.323-.993.656-1.451 1.005l-.228.164.164-.228c.349-.458.682-.944 1.005-1.451l.655-1.029-.134-.652a9.87 9.87 0 01-.267-2.414c0-5.471 4.409-9.922 9.868-9.922 2.646 0 5.147.997 7.078 2.837l.405.376.376-.405a9.865 9.865 0 002.837-7.078c0-5.471-4.409-9.922-9.868-9.922"/>
                </svg>
                Enviar para WhatsApp
              </Button>
              <Button
                onClick={() => setShowConfirmation(false)}
                className="w-full bg-gray-200 hover:bg-gray-300 text-black py-3 font-semibold transition-colors"
              >
                Voltar ao Carrinho
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
