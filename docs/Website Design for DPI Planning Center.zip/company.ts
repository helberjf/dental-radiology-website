export const company = {
  name: "DPI Planning Center",
  description: "Laboratório digital especializado em serviços e soluções para odontologia digital.",
  address: "Av Juscelino Kubitschek, 900 - Sala 312, Francisco Bernardino - Juiz de Fora, MG",
  whatsapp: "32991392808",
  email: "dpiriobranco@gmail.com",
  instagram: null,
  facebook: null,
  logo: "/manus-storage/dpi_planning_center_logo_2f66b596.png",
};

export const whatsappLink = `https://wa.me/55${company.whatsapp.replace(/\D/g, "")}`;

export const formatWhatsapp = (phone: string) => {
  const cleaned = phone.replace(/\D/g, "");
  return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 7)}-${cleaned.slice(7)}`;
};

